function getInfo() {
    let stopId = document.querySelector('#stopId').value;
    let urlBase = `https://judgetests.firebaseio.com/businfo/${stopId}.json`;
    getBus().catch(error =>{
        console.log(error);
        document.querySelector('#stopName').textContent = 'Error';
    });
    async function getBus(){
        const response = await fetch(urlBase);
        const info = await response.json();
        let stopName = document.querySelector('#stopName');
        let buses = document.querySelector('#buses');
        let busInfo = Object.entries(info.buses);
        stopName.textContent = info.name;
        document.getElementById('buses').textContent = '';
        busInfo.forEach(x=>{
            let li = document.createElement('li');
            li.textContent = `Bus ${x[0]} arrives in ${x[1]} minutes`;
            buses.appendChild(li);
        });

    }
    getBus();
}