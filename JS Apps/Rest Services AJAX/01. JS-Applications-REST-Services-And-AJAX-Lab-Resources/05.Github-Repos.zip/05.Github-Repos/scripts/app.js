function loadRepos() {
    document.querySelector('#repos li a').textContent = '';
    let nameOfUser = document.querySelector('#username').value;

    let url = `https://api.github.com/users/${nameOfUser}/repos`
    let req = new XMLHttpRequest();

    req.onreadystatechange = (ev)=>{
        let targer = ev.target;
        let whatIneed = JSON.parse(targer.responseText);
        whatIneed.map(x=>{
            let listItem = document.querySelector('#repos li');
            let aItem = document.createElement('a');
            var mybr = document.createElement('br');

            aItem.href = x.html_url;
            aItem.textContent = x.full_name;
            listItem.appendChild(aItem);
            listItem.appendChild(mybr);
        });
    }
    req.open('GET',url,true);
    req.send();
}