function solve() {
    let userData = JSON.parse(document.querySelector('#arr').value)
   let pattern = /^([A-Z][a-z]{0,})\s([A-Z][a-z]{0,})\s([+359]+([\s|-])\d\4\d+\4\d+)\s([a-z]+\@[a-z]{1,}.[a-z]{2,3})$/g
   for(let user of userData){
       let p = document.createElement('p')
       if(user.match(pattern)){
           let data = pattern.exec(user)
           p.textContent = `Name: ${data[1]} ${data[2]}\n\nEmail: ${data[5]}`
           document.querySelector('#result').appendChild(p)

       }else{
            p.textContent = 'Invalid data'
            document.querySelector('#result').appendChild(p)
       }
   }
}